module.exports = {

"[project]/app/AC/page.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
const page = ()=>{
    const members = [
        {
            sr: 1,
            Section: "26 (3) (a)",
            Name: "Prin. Dr. Dnyandeo Mhaske	",
            PositiontUniversity: "Vice-Chancellor		",
            Designation: "Chairperson"
        },
        {
            sr: 2,
            Section: "26 (3) (b)",
            Name: "Prin. Dr. B. T. Jadhav	",
            PositiontUniversity: "Principal of the Constituent College;		",
            Designation: "Member"
        },
        {
            sr: 3,
            Section: "26 (3) (b)",
            Name: "Prin. Dr. Rajendra More	",
            PositiontUniversity: "Principal of the Constituent College;	",
            Designation: "Member"
        },
        {
            sr: 4,
            Section: "26 (3) (b)",
            Name: "Prin. Dr. D.K. Mhaske		",
            PositiontUniversity: "Principal of the Constituent College;	",
            Designation: "Member"
        },
        {
            sr: 5,
            Section: "	23 (2) (c)",
            Name: "Prof. Dr. Rajan More	",
            PositiontUniversity: "Dean, Faculty of Science and Technology	",
            Designation: "Member"
        },
        {
            sr: 6,
            Section: "	26 (3) (c)",
            Name: "	Prof.(Dr.) A. K. Wavare",
            PositiontUniversity: "Dean, Faculty of Humanities",
            Designation: "Member"
        },
        {
            sr: 7,
            Section: "	26 (3) (c)",
            Name: "Prof.(Dr.) V. K. Sawant",
            PositiontUniversity: "Dean, Faculty of Commerce and Management",
            Designation: "Member"
        },
        {
            sr: 8,
            Section: "	26 (3) (c)",
            Name: "Prof.(Dr.) R.R. Salunkhe",
            PositiontUniversity: "Dean, Faculty of Interdisciplinary Studies",
            Designation: "Member"
        },
        {
            sr: 9,
            Section: "23 (2) (d)",
            Name: "Prof. Dr. D.D. Namdas",
            PositiontUniversity: "	Head of Departments of the University; nominated by the Vice-Chancellor",
            Designation: "Member"
        },
        {
            sr: 10,
            Section: "23 (2) (d)",
            Name: "Prof. Dr. S. D. Waghmare	",
            PositiontUniversity: "	Head of Departments of the University; nominated by the Vice-Chancellor",
            Designation: "Member"
        },
        {
            sr: 11,
            Section: "23 (2) (d)",
            Name: "Prof. Dr. G.V. Jadhav	",
            PositiontUniversity: "Head of Departments of the University; nominated by the Vice-Chancellor",
            Designation: "Member"
        },
        {
            sr: 12,
            Section: "	23 (2) (e)",
            Name: "Shri. Sagar Deshpande	",
            PositiontUniversity: "Professors or Associate Professor from Constituent Colleges or subjects other than those represented by the Principals",
            Designation: "Member"
        },
        {
            sr: 13,
            Section: "		23 (2) (e)",
            Name: "Shri. Sagar Deshpande	",
            PositiontUniversity: "Professors or Associate Professor from Constituent Colleges or subjects other than those represented by the Principals;",
            Designation: "Member"
        },
        {
            sr: 14,
            Section: "	23 (2) (f)",
            Name: "Shri. Sagar Deshpande	",
            PositiontUniversity: "Teacher who are not principals of constituent colleges to be nominated by the Vice-Chancellor;",
            Designation: "Member"
        },
        {
            sr: 15,
            Section: "	23 (2) (f)",
            Name: "Shri. Sagar Deshpande	",
            PositiontUniversity: "	Teacher who are not principals of constituent colleges to be nominated by the Vice-Chancellor;",
            Designation: "Member"
        },
        {
            sr: 16,
            Section: "	23 (2) (g)",
            Name: "Shri. Sagar Deshpande	",
            PositiontUniversity: "	Other external experts as per requirement, representing various disciplines to be nominated by the Provost;",
            Designation: "Member"
        },
        {
            sr: 17,
            Section: "	23 (2) (g)",
            Name: "Shri. Sagar Deshpande	",
            PositiontUniversity: "Other external experts as per requirement, representing various disciplines to be nominated by the Provost;",
            Designation: "Member"
        },
        {
            sr: 18,
            Section: "	23 (2) (g)",
            Name: "Shri. Vidyadhar Anaskar	",
            PositiontUniversity: "Other external experts as per requirement, representing various disciplines to be nominated by the Provost;	",
            Designation: "Member"
        },
        {
            sr: 19,
            Section: "	23 (2) (g)",
            Name: "Prof. Dr. A. D. Shaligram	",
            PositiontUniversity: "	Other external experts as per requirement, representing various disciplines to be nominated by the Provost;",
            Designation: "Member"
        },
        {
            sr: 20,
            Section: "	23 (2) (g)",
            Name: "Dr. Sarang Shankar Bhola	",
            PositiontUniversity: "Other external experts as per requirement, representing various disciplines to be nominated by the Provost;",
            Designation: "Member"
        },
        {
            sr: 21,
            Section: "	23 (2) (g)",
            Name: "Prof. Dr. Sadananad More	",
            PositiontUniversity: "	Other external experts as per requirement, representing various disciplines to be nominated by the Provost;",
            Designation: "Member"
        },
        {
            sr: 22,
            Section: "23 (2) (h)",
            Name: "Prof. Dr. Mrs. S. A. Kurkute	",
            PositiontUniversity: "One alumnus student nominated by the Vice-Chancellor.",
            Designation: "Member"
        },
        {
            sr: 23,
            Section: "-",
            Name: "Registrar	",
            PositiontUniversity: "	Registrar of the University",
            Designation: "	Member Secetary"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-[250px] bg-cover bg-center relative bg-black",
                style: {
                    backgroundImage: "url('/images/tback.png')"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-black opacity-45"
                    }, void 0, false, {
                        fileName: "[project]/app/AC/page.js",
                        lineNumber: 183,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative z-10 flex flex-col items-center justify-center h-full text-white text-center px-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-lg md:text-4xl font-bold font-['Times_New_Roman']",
                                children: "Academic Council"
                            }, void 0, false, {
                                fileName: "[project]/app/AC/page.js",
                                lineNumber: 185,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "border-t-2 border-white w-full max-w-[500px] my-4"
                            }, void 0, false, {
                                fileName: "[project]/app/AC/page.js",
                                lineNumber: 186,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-white py-3 px-6 flex flex-wrap justify-center items-center gap-2 text-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        src: "/images/breadcrumb.png",
                                        alt: "breadcrumb",
                                        width: 20,
                                        height: 20,
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/app/AC/page.js",
                                        lineNumber: 188,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "hover:underline cursor-pointer",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/",
                                            children: "Home"
                                        }, void 0, false, {
                                            fileName: "[project]/app/AC/page.js",
                                            lineNumber: 189,
                                            columnNumber: 74
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/AC/page.js",
                                        lineNumber: 189,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "/"
                                    }, void 0, false, {
                                        fileName: "[project]/app/AC/page.js",
                                        lineNumber: 190,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "hover:underline cursor-pointer",
                                        children: "Boards and Committees"
                                    }, void 0, false, {
                                        fileName: "[project]/app/AC/page.js",
                                        lineNumber: 191,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "/"
                                    }, void 0, false, {
                                        fileName: "[project]/app/AC/page.js",
                                        lineNumber: 192,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-yellow-400 font-semibold",
                                        children: "Academic Council"
                                    }, void 0, false, {
                                        fileName: "[project]/app/AC/page.js",
                                        lineNumber: 193,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/AC/page.js",
                                lineNumber: 187,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/AC/page.js",
                        lineNumber: 184,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/AC/page.js",
                lineNumber: 179,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full px-4 py-6 overflow-x-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full max-w-7xl mx-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: "min-w-[800px] w-full border border-black text-sm md:text-base bg-white shadow",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                className: "bg-gray-400 text-gray-900",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "border border-gray-300 px-4 py-2 text-left",
                                            children: "Sr.No."
                                        }, void 0, false, {
                                            fileName: "[project]/app/AC/page.js",
                                            lineNumber: 204,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "border border-gray-300 px-4 py-2 text-left",
                                            children: "Section"
                                        }, void 0, false, {
                                            fileName: "[project]/app/AC/page.js",
                                            lineNumber: 205,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "border border-gray-300 px-4 py-2 text-left",
                                            children: "Name"
                                        }, void 0, false, {
                                            fileName: "[project]/app/AC/page.js",
                                            lineNumber: 206,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "border border-gray-300 px-4 py-2 text-left",
                                            children: "Position at University"
                                        }, void 0, false, {
                                            fileName: "[project]/app/AC/page.js",
                                            lineNumber: 207,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "border border-gray-300 px-4 py-2 text-left",
                                            children: "Designation"
                                        }, void 0, false, {
                                            fileName: "[project]/app/AC/page.js",
                                            lineNumber: 208,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/AC/page.js",
                                    lineNumber: 203,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/AC/page.js",
                                lineNumber: 202,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: members.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "hover:bg-gray-100 transition",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "border border-gray-300 px-4 py-2",
                                                children: m.sr
                                            }, void 0, false, {
                                                fileName: "[project]/app/AC/page.js",
                                                lineNumber: 214,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "border border-gray-300 px-4 py-2",
                                                children: m.Section
                                            }, void 0, false, {
                                                fileName: "[project]/app/AC/page.js",
                                                lineNumber: 215,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "border border-gray-300 px-4 py-2",
                                                children: m.Name
                                            }, void 0, false, {
                                                fileName: "[project]/app/AC/page.js",
                                                lineNumber: 216,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "border border-gray-300 px-4 py-2",
                                                children: m.PositiontUniversity
                                            }, void 0, false, {
                                                fileName: "[project]/app/AC/page.js",
                                                lineNumber: 217,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "border border-gray-300 px-4 py-2",
                                                children: m.Designation
                                            }, void 0, false, {
                                                fileName: "[project]/app/AC/page.js",
                                                lineNumber: 218,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, m.sr, true, {
                                        fileName: "[project]/app/AC/page.js",
                                        lineNumber: 213,
                                        columnNumber: 33
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/AC/page.js",
                                lineNumber: 211,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/AC/page.js",
                        lineNumber: 201,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/AC/page.js",
                    lineNumber: 200,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/AC/page.js",
                lineNumber: 199,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/AC/page.js",
        lineNumber: 177,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = page;
}}),

};

//# sourceMappingURL=app_AC_page_ae132e5b.js.map