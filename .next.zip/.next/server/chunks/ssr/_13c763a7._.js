module.exports = {

"[project]/.next-internal/server/app/MandatoryDisclosure/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/app/layout.js [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.js [app-rsc] (ecmascript)"));
}}),
"[project]/app/MandatoryDisclosure/page.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-rsc] (ecmascript)");
;
;
;
;
;
const page = ()=>{
    const data = [
        {
            id: 1,
            Title: "1) About HEI/University",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "#",
                target: "blank"
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 10,
                columnNumber: 14
            }, this)
        },
        {
            id: 2,
            Title: "a) About us: Overview	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/pdf/about-us.pdf",
                target: "blank",
                children: " About us"
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 14,
                columnNumber: 16
            }, this)
        },
        {
            id: 3,
            Title: " ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Karmaveer Bhaurao Patil University, Satara"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 20,
                    columnNumber: 7
                }, this)
            }, void 0, false)
        },
        {
            id: 4,
            Title: "• Address of the university:	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Address: 4th Floor G-Building Ycis Powai Naka, Satara, Maharashtra 415001"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 30,
                    columnNumber: 11
                }, this)
            }, void 0, false)
        },
        {
            id: 5,
            Title: "• Telephone No. email id		",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Phone: 02162 229 907, Email: registrar@unikbp.ac.in"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 42,
                    columnNumber: 6
                }, this)
            }, void 0, false)
        },
        {
            id: 6,
            Title: "• Website Link:	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "  https://unikbp.ac.in",
                target: "blank",
                children: " https://unikbp.ac.in"
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 50,
                columnNumber: 17
            }, this)
        },
        {
            id: 7,
            Title: " b) Act and Statutes or MoA (provide link)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " /Admission/",
                target: "blank",
                children: " https://unikbp.ac.in/admission/"
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 54,
                columnNumber: 16
            }, this)
        },
        {
            id: 8,
            Title: "• Initially Submitted DPR: (in case of a self-financed university)	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Not Applicable"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 60,
                    columnNumber: 9
                }, this)
            }, void 0, false)
        },
        {
            id: 9,
            Title: "• Compliance of the DPR so far: (in case of a self-financed university)		",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Not Applicable"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 70,
                    columnNumber: 7
                }, this)
            }, void 0, false)
        },
        {
            id: 10,
            Title: "• Previous Year's Annual Report (provide Link)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                target: "blank",
                                children: "Click Here(Marathi) "
                            }, void 0, false, {
                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                lineNumber: 81,
                                columnNumber: 5
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/MandatoryDisclosure/page.js",
                            lineNumber: 81,
                            columnNumber: 1
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                target: "blank",
                                children: "Click Here(English)"
                            }, void 0, false, {
                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                lineNumber: 82,
                                columnNumber: 5
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/MandatoryDisclosure/page.js",
                            lineNumber: 82,
                            columnNumber: 1
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 80,
                    columnNumber: 3
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 79,
                columnNumber: 1
            }, this)
        },
        {
            id: 11,
            Title: "c) Institutional Development Plan (Next Five year)		",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Perspective Plan - IDP in progress"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 93,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 12,
            Title: "• Constituent Units/other campus (Wherever applicable)		",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Not Applicable"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 103,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 13,
            Title: "d) AISHE code		",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "U-0325hyoip"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 113,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 14,
            Title: "d) AISHE code		",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "U-0325"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 123,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 15,
            Title: "• Link to the proforma		",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " DCF-I",
                target: "blank",
                children: " DCF-I"
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 131,
                columnNumber: 10
            }, this)
        },
        {
            id: 16,
            Title: " e) Accreditation / Ranking (NAAC, NIRF) Details of IQAC (act 6(7))	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 136,
                columnNumber: 8
            }, this)
        },
        {
            id: 17,
            Title: " NAAC",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " Accreditation Report and Action Plan NIRF DATA IQAC",
                target: "blank",
                children: "  Accreditation Report and Action Plan NIRF DATA IQAC "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 141,
                columnNumber: 8
            }, this)
        },
        {
            id: 18,
            Title: "Accreditation status: NAAC (act 6 (6))	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "A++ with CGPA 3.52"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 148,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 19,
            Title: " • Validity of Accreditation	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: ": March 30, 2026"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 159,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 20,
            Title: " • AQAR: (provide Link)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " AQAR",
                target: "blank",
                children: "  AQAR "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 167,
                columnNumber: 8
            }, this)
        },
        {
            id: 21,
            Title: " SSR (provide Link)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " Self Study Report",
                target: "blank",
                children: "  Self Study Report "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 172,
                columnNumber: 8
            }, this)
        },
        {
            id: 22,
            Title: " • NBA	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Not accredited"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 179,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 23,
            Title: " • Number of courses with NBA accreditation	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Nil    "
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 190,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 24,
            Title: "• NIRF Ranking:	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "NIRF Ranking List (Rank Band 151-200)"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 200,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 25,
            Title: " • Application :	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "NIRF DATA",
                target: "blank",
                children: " NIRF DATA "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 209,
                columnNumber: 8
            }, this)
        },
        {
            id: 26,
            Title: "• Other Rankings (if any)	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 214,
                columnNumber: 8
            }, this)
        },
        {
            id: 27,
            Title: " 2) Trust (whom so ever applicable for)	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Not Applicable"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 221,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 28,
            Title: "• Name and address of the /sponsoring body / Trust/Society/Company and the Trustees (if Any)	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "----"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 232,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 29,
            Title: "• Address including Telephone, Mobile, E-Mail	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "----"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 243,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 30,
            Title: "3) Administration (Profiles with photographs)	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 252,
                columnNumber: 8
            }, this)
        },
        {
            id: 31,
            Title: " • University/HEI Organogram Chart	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " Organogram Chart",
                target: "blank",
                children: "  Organogram Chart "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 256,
                columnNumber: 8
            }, this)
        },
        {
            id: 32,
            Title: " • Chancellor	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "https://rajbhavan-maharashtra.gov.in/en/governors-profile/",
                target: "blank",
                children: "   Chancellor Profile "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 260,
                columnNumber: 8
            }, this)
        },
        {
            id: 33,
            Title: " • Vice Chancellor	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/pdf/Vicechancellor.pdf",
                target: "blank",
                children: " Vice Chancellor Profile  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 264,
                columnNumber: 8
            }, this)
        },
        {
            id: 34,
            Title: " • Pro-Vice-Chancellor (wherever applicable)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " /pdf/Vicechancellor.pdf",
                target: "blank",
                children: "  Pro-Vice Chancellor Profile "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 268,
                columnNumber: 8
            }, this)
        },
        {
            id: 35,
            Title: " • Registrar	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/pdf/DrVijayKumbhar.pdf",
                target: "blank",
                children: " Registrar Profile "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 272,
                columnNumber: 8
            }, this)
        },
        {
            id: 36,
            Title: " • Finance Officer	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/FinanceandAccounts",
                target: "blank",
                children: " Finance Officer Profile  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 276,
                columnNumber: 8
            }, this)
        },
        {
            id: 37,
            Title: " • Controller of Examination	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " /DirectorBOEE",
                target: "blank",
                children: "  Controller of Examination Profile "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 280,
                columnNumber: 8
            }, this)
        },
        {
            id: 38,
            Title: " • Chief Vigilance Officer	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " Chief Vigilance Officer Profile",
                target: "blank",
                children: "  Chief Vigilance Officer Profile "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 284,
                columnNumber: 8
            }, this)
        },
        {
            id: 39,
            Title: " • Executive Council, Academic Council, Board of Studies, Finance Committee	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "",
                                target: "blank",
                                children: "  Executive Council"
                            }, void 0, false, {
                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                lineNumber: 291,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/MandatoryDisclosure/page.js",
                            lineNumber: 291,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "",
                                target: "blank",
                                children: "  Board of Studies "
                            }, void 0, false, {
                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                lineNumber: 292,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/MandatoryDisclosure/page.js",
                            lineNumber: 292,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "",
                                target: "blank",
                                children: " Academic Council "
                            }, void 0, false, {
                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                lineNumber: 293,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/MandatoryDisclosure/page.js",
                            lineNumber: 293,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "",
                                target: "blank",
                                children: " Finance Committee"
                            }, void 0, false, {
                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                lineNumber: 294,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/MandatoryDisclosure/page.js",
                            lineNumber: 294,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 290,
                    columnNumber: 7
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 289,
                columnNumber: 5
            }, this)
        },
        {
            id: 40,
            Title: "4) Profile of Vice Chancellor/Director/Principal	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/pdf/Vicechancellor.pdf",
                target: "blank",
                children: " Hon. VC Profile "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 301,
                columnNumber: 8
            }, this)
        },
        {
            id: 41,
            Title: "5) Academics	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/AcademicsProgram",
                target: "blank",
                children: "PG academics-programs Admission  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 305,
                columnNumber: 8
            }, this)
        },
        {
            id: 42,
            Title: "a) Academic Programs	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/AcademicsProgram",
                target: "blank",
                children: "  Link to Programs "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 309,
                columnNumber: 8
            }, this)
        },
        {
            id: 43,
            Title: " b) Names of the Schools/Divisions/Departments/Centers	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " Link to Departments "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 313,
                columnNumber: 8
            }, this)
        },
        {
            id: 44,
            Title: " c) Total Number of Programs under Each School	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  Link from PG Admission "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 317,
                columnNumber: 8
            }, this)
        },
        {
            id: 45,
            Title: " d) Internship and Placement (Program-wise)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 321,
                columnNumber: 8
            }, this)
        },
        {
            id: 46,
            Title: " e) Academic Calendar	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 325,
                columnNumber: 8
            }, this)
        },
        {
            id: 47,
            Title: " f) Library: Basic Information at a Glance	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  Library Info "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 329,
                columnNumber: 8
            }, this)
        },
        {
            id: 48,
            Title: "6) NEP Implementation Strategies	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " NEP Syllabus "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 333,
                columnNumber: 8
            }, this)
        },
        {
            id: 49,
            Title: " 7) Prospectus (including fee structure for various programs)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  view "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 337,
                columnNumber: 8
            }, this)
        },
        {
            id: 50,
            Title: "8) Faculty	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " Faculty Information "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 341,
                columnNumber: 8
            }, this)
        },
        {
            id: 51,
            Title: "9) Permanent Faculty: Students Ratio	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "1:19"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 347,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 52,
            Title: " 10) International Students and Collaboration	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 356,
                columnNumber: 8
            }, this)
        },
        {
            id: 53,
            Title: " • Admission Guidelines for International Students	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " Admission Guidelines "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 361,
                columnNumber: 8
            }, this)
        },
        {
            id: 54,
            Title: "• Facilities Provided to International Students	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  Facilities Info "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 366,
                columnNumber: 8
            }, this)
        },
        {
            id: 55,
            Title: " • Name and Duration of Twinning Programs with Foreign Universities	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Medical Information Management (Duration: 2 years)"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 372,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 56,
            Title: " • If there is Foreign Collaboration	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "MOU link ??? EST/EST PG"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 382,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 57,
            Title: " 11) Research	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 390,
                columnNumber: 8
            }, this)
        },
        {
            id: 58,
            Title: " • Research and Development Cell	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " Research Development Cell "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 394,
                columnNumber: 8
            }, this)
        },
        {
            id: 59,
            Title: " • Publications	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  Publications "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 398,
                columnNumber: 8
            }, this)
        },
        {
            id: 60,
            Title: "• Patents (Published/Applied)	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "Patents  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 402,
                columnNumber: 8
            }, this)
        },
        {
            id: 61,
            Title: " • Industry Collaborations	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "IQAC"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 408,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 62,
            Title: " • Central Facilities	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  Central Facilities "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 416,
                columnNumber: 8
            }, this)
        },
        {
            id: 63,
            Title: "• MoUs	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  MoUs "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 420,
                columnNumber: 8
            }, this)
        },
        {
            id: 64,
            Title: " • Shodhganga and Shodhgangotri	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  Shodhganga "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 424,
                columnNumber: 8
            }, this)
        },
        {
            id: 65,
            Title: "12) Infrastructure (Information of Infrastructure and Other Resources Available)	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 428,
                columnNumber: 8
            }, this)
        },
        {
            id: 66,
            Title: "• Number of Tutorial rooms and size of each	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 432,
                columnNumber: 8
            }, this)
        },
        {
            id: 67,
            Title: " • Number of Drawing Halls with capacity of each	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 436,
                columnNumber: 8
            }, this)
        },
        {
            id: 68,
            Title: " • Number of Computer Centers with capacity of each	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 440,
                columnNumber: 8
            }, this)
        },
        {
            id: 69,
            Title: " • Central Examination Facility, Number of rooms and capacity of each	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "?"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 446,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 70,
            Title: "• Online examination facility (Number of Nodes, Internet bandwidth, etc.)	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "?"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 456,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 71,
            Title: "• Barrier Free Built Environment for disabled and elderly persons	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "?"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 466,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 72,
            Title: "• Fire and Safety Certificate	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "?"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 476,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 73,
            Title: " • Hostel Facilities	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 484,
                columnNumber: 8
            }, this)
        },
        {
            id: 74,
            Title: "• Library	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 488,
                columnNumber: 8
            }, this)
        },
        {
            id: 75,
            Title: " • List of Major Equipment/Facilities in each Laboratory/Workshop	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 492,
                columnNumber: 8
            }, this)
        },
        {
            id: 76,
            Title: "• Computing Facilities	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "?"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 498,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 77,
            Title: "• Internet Bandwidth	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 506,
                columnNumber: 8
            }, this)
        },
        {
            id: 78,
            Title: "• Innovation Cell	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "#  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 511,
                columnNumber: 8
            }, this)
        },
        {
            id: 79,
            Title: " • Social Media Cell	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "#  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 516,
                columnNumber: 8
            }, this)
        },
        {
            id: 80,
            Title: " List of facilities available	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  Click Here "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 521,
                columnNumber: 8
            }, this)
        },
        {
            id: 81,
            Title: " To upload the respective short video (1 - 2 min) of Infrastructure and facilities available w.r.t the courses in the website	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 526,
                columnNumber: 8
            }, this)
        },
        {
            id: 82,
            Title: " • Games and Sports Facilities	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 531,
                columnNumber: 8
            }, this)
        },
        {
            id: 83,
            Title: "• Teaching Learning Process	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " IQAC "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 536,
                columnNumber: 8
            }, this)
        },
        {
            id: 84,
            Title: " • Academic Time Table with the name of the Faculty members handling the Course	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " ??  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 541,
                columnNumber: 8
            }, this)
        },
        {
            id: 85,
            Title: " • For each Post Graduate Courses give the following: Title of the Course	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "PG Admission  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 546,
                columnNumber: 8
            }, this)
        },
        {
            id: 86,
            Title: " • Laboratory facilities exclusive to the Post Graduate Course	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " PG Admission  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 551,
                columnNumber: 8
            }, this)
        },
        {
            id: 87,
            Title: " 13) Student Life	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 556,
                columnNumber: 8
            }, this)
        },
        {
            id: 88,
            Title: "• Available hostel accommodation	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 561,
                columnNumber: 8
            }, this)
        },
        {
            id: 89,
            Title: " • Fellowships/ Scholarships (provide details)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 566,
                columnNumber: 8
            }, this)
        },
        {
            id: 90,
            Title: " • Academic Bank of Credits (provide link)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "https://www.abc.gov.in/",
                target: "blank",
                children: " https://www.abc.gov.in/ "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 571,
                columnNumber: 8
            }, this)
        },
        {
            id: 91,
            Title: "• Digi Locker NAD Portal (provide link)	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " http://www.nad.gov.in/",
                target: "blank",
                children: "  http://www.nad.gov.in/ "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 576,
                columnNumber: 8
            }, this)
        },
        {
            id: 92,
            Title: " • National Scholarship Portal (provide link)	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "PG Admission"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 583,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 93,
            Title: " 14) Campus Harmony & Well Being	"
        },
        {
            id: 94,
            Title: " • e-Samadhan (Provide link)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: " https://samadhaan.ugc.ac.in/",
                target: "blank",
                children: "  https://samadhaan.ugc.ac.in/ "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 597,
                columnNumber: 8
            }, this)
        },
        {
            id: 95,
            Title: " • Student Grievance Redressal Committee (SGRC)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/SGRC",
                target: "blank",
                children: "  https:https://unikbp.ac.in/students-grievance-redressal-committee-sgrc/"
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 602,
                columnNumber: 8
            }, this)
        },
        {
            id: 96,
            Title: "• Details of OMBUDSPERSON	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 607,
                columnNumber: 8
            }, this)
        },
        {
            id: 97,
            Title: " • Internal Quality Assurance Cell	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  https://unikbp.ac.in/director-internal-quality-assurance-cell-iqac/ "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 612,
                columnNumber: 8
            }, this)
        },
        {
            id: 98,
            Title: " • Internal Complaint Committee to address complaints of Sexual Harassment	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/ICC",
                target: "blank",
                children: "  https://unikbp.ac.in/internal-complaints-committee-icc/ "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 617,
                columnNumber: 8
            }, this)
        },
        {
            id: 99,
            Title: " • Anti-Ragging Cell with Helpline number	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/Antirag",
                target: "blank",
                children: "  https://unikbp.ac.in/anti-ragging/ "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 622,
                columnNumber: 8
            }, this)
        },
        {
            id: 100,
            Title: "• Equal Opportunity Cell	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "?"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 628,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 101,
            Title: "• Socio-Economically Disadvantaged Group Cell (SEDG)	 ",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "?    "
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 639,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 102,
            Title: "• Alumni	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 647,
                columnNumber: 8
            }, this)
        },
        {
            id: 103,
            Title: "• Alumni Association (provide link of portal wherever applicable)	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 652,
                columnNumber: 8
            }, this)
        },
        {
            id: 104,
            Title: "• Alumni Co-ordination Cell	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 657,
                columnNumber: 8
            }, this)
        },
        {
            id: 105,
            Title: "15) Information Corner	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 662,
                columnNumber: 8
            }, this)
        },
        {
            id: 106,
            Title: " • RTI: Details of CPIO and Appellate authority (wherever applicable)	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "???  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 667,
                columnNumber: 8
            }, this)
        },
        {
            id: 107,
            Title: " • Circular and Notices	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "#  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 672,
                columnNumber: 8
            }, this)
        },
        {
            id: 108,
            Title: " Announcements",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 677,
                columnNumber: 8
            }, this)
        },
        {
            id: 109,
            Title: "• Newsletters	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 682,
                columnNumber: 8
            }, this)
        },
        {
            id: 110,
            Title: "• News, Recent events & Achievements	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: " # "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 687,
                columnNumber: 8
            }, this)
        },
        {
            id: 111,
            Title: " Job openings	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/Recruitment",
                target: "blank",
                children: " https://unikbp.ac.in/recruitment/ "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 692,
                columnNumber: 8
            }, this)
        },
        {
            id: 112,
            Title: " • Reservation Roster (wherever applicable)	",
            text: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "• Special Cell"
                }, void 0, false, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 699,
                    columnNumber: 5
                }, this)
            }, void 0, false)
        },
        {
            id: 113,
            Title: "• Important Instructions	 ",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 708,
                columnNumber: 8
            }, this)
        },
        {
            id: 114,
            Title: " • The mandatory disclosure should be available freely to view/download to the public without any restrictions.	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 713,
                columnNumber: 8
            }, this)
        },
        {
            id: 115,
            Title: " • The complete mandatory disclosure document should be converted into a single PDF file and the URL (web link).	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 718,
                columnNumber: 8
            }, this)
        },
        {
            id: 116,
            Title: " ESTABLISHMENT--विद्यार्थी व सामान्य जनतेसाठी अनिवार्यपणे स्वप्रमाणितीकरण करावयाच्या माहितीबाबत शासन परिपत्रक दिनांक ८ फेब्रुवारी, २०२४ च्या अनुसरणाने परिपत्रक	",
            link: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "",
                target: "blank",
                children: "  "
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 723,
                columnNumber: 8
            }, this)
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-[250px] bg-cover bg-center relative bg-black",
                style: {
                    backgroundImage: "url('/images/tback.png')"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-black opacity-45"
                    }, void 0, false, {
                        fileName: "[project]/app/MandatoryDisclosure/page.js",
                        lineNumber: 741,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative z-10 flex flex-col items-center justify-center h-full text-white text-center px-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-xl md:text-4xl font-bold font-['Times_New_Roman']",
                                children: "Mandatory Disclosure"
                            }, void 0, false, {
                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                lineNumber: 743,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "border-t-2 border-white w-[70%] max-w-[500px] my-4"
                            }, void 0, false, {
                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                lineNumber: 746,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-white py-3 px-6 flex items-center space-x-2 text-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                        src: "/images/breadcrumb.png",
                                        alt: "breadcrumb",
                                        width: 20,
                                        height: 20,
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/app/MandatoryDisclosure/page.js",
                                        lineNumber: 748,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "hover:underline cursor-pointer",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/",
                                            children: "Home"
                                        }, void 0, false, {
                                            fileName: "[project]/app/MandatoryDisclosure/page.js",
                                            lineNumber: 756,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/MandatoryDisclosure/page.js",
                                        lineNumber: 755,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "/"
                                    }, void 0, false, {
                                        fileName: "[project]/app/MandatoryDisclosure/page.js",
                                        lineNumber: 758,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[#fbbf24] font-semibold",
                                        children: "Mandatory Disclosure"
                                    }, void 0, false, {
                                        fileName: "[project]/app/MandatoryDisclosure/page.js",
                                        lineNumber: 759,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                lineNumber: 747,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/MandatoryDisclosure/page.js",
                        lineNumber: 742,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 737,
                columnNumber: 3
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center p-10 ",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                    className: "border border-black w-auto text-black justify-center p-4 items-center shadow-lg",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "bg-gray-900 border border-white px-4 py-2 text-white",
                                        children: "Format of information to be publish on the website (Please fill information, as applicable)"
                                    }, void 0, false, {
                                        fileName: "[project]/app/MandatoryDisclosure/page.js",
                                        lineNumber: 769,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "bg-gray-900 border border-white  px-4 py-2 text-white",
                                        children: "Present Status/ Concerned Section"
                                    }, void 0, false, {
                                        fileName: "[project]/app/MandatoryDisclosure/page.js",
                                        lineNumber: 773,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                lineNumber: 768,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/MandatoryDisclosure/page.js",
                            lineNumber: 767,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: data.map((T)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: [
                                            T.Title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "border border-black px-4 py-2",
                                                children: T.Title
                                            }, void 0, false, {
                                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                                lineNumber: 785,
                                                columnNumber: 21
                                            }, this),
                                            T.link && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "text-blue-600 underline border border-black px-4 py-2",
                                                children: T.link
                                            }, void 0, false, {
                                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                                lineNumber: 788,
                                                columnNumber: 21
                                            }, this),
                                            T.text && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "e border border-black px-4 py-2",
                                                children: T.text
                                            }, void 0, false, {
                                                fileName: "[project]/app/MandatoryDisclosure/page.js",
                                                lineNumber: 792,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/MandatoryDisclosure/page.js",
                                        lineNumber: 783,
                                        columnNumber: 19
                                    }, this)
                                }, T.id, false, {
                                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                                    lineNumber: 782,
                                    columnNumber: 16
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/MandatoryDisclosure/page.js",
                            lineNumber: 778,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/MandatoryDisclosure/page.js",
                    lineNumber: 766,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/MandatoryDisclosure/page.js",
                lineNumber: 763,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/MandatoryDisclosure/page.js",
        lineNumber: 734,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = page;
}}),
"[project]/app/MandatoryDisclosure/page.js [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/MandatoryDisclosure/page.js [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_13c763a7._.js.map